int arr[10] = {1,2,3,4,5,6,7,8,9,10};

enum DayOfWeek {
    Sunday = 0,
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday
};

int sum(int a, int b) {
	return a + b;
}

void main() {
	printf("%d", sum(3,4));
}




