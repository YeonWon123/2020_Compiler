void main() {
	int x = 3;
	int a = 1;
	int b = 2;
	int c = 3;
	int d = 0;
	
	while(1) {
		if (x <= 5) 
			break;
		else
			x--;
	}


	if (a + b * c || d) {
		x = a > b && a % c;
	}
	else {
		return (x + 10);
	}
}



