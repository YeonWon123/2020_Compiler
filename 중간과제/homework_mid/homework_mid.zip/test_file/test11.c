static int *kim[10], j = 20 + 30;
int lee[2][2] = {{1,2}, {3,4}};
float **ptr;
char (*name)[10];
typedef struct ST{
	int a;
	int b;
} st;

int main() {
	st lee[10];
	lee[9].a++;
	lee[8].b--;
}

