int main() {
	int a = 1;
	int b;

	if (a == 0) {
		b = 3;
	}
	else {
		b = 4;
	}

	for (;;) {
		printf("출력을 해요");
	}
}



