void main() {
	int a = 3;
	int b = 4;
	printf("%d\n", a+b);
}
