enum ee { A, B=10 } (*kim[10+5]) (int a);
