int main(){
	int a = 3;
	int b = 4;
	int c = a + b;
	if(a==b) {
		printf("this is same!");
		return 1;
	}
	else {
		return 0;
	}
}

